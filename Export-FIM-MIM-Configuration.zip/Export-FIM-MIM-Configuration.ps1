### Abstract: This PoSH Script Exports The FIM/MIM Configuration
### Written by: Jorge de Almeida Pinto [MVP-EMS]
### BLOG: http://jorgequestforknowledge.wordpress.com/
###
### 2016-09-25: Initial version of the script (v0.1)
###

Param(
	[switch]$allConfig,					# Exports All The Configuration Of FIM/MIM
	[switch]$mainConfig,				# Exports The Main Configuration Of FIM/MIM
	[switch]$fimSyncConfig,				# Exports The FIM Sync Specific Configuration
	[switch]$fimSvcConfig,				# Exports The FIM Service Specific Configuration
	[switch]$fimPortalConfig,			# Exports The FIM Portal Specific Configuration
	[switch]$fimPwdRegPortalConfig,		# Exports The FIM Password Registration Portal Specific Configuration
	[switch]$fimPwdResetPortalConfig,	# Exports The FIM Password Reset Portal Specific Configuration
	[switch]$backupDBs,					# Backup The Databases In Use By FIM
	[string]$mainBackupFolder			# Main Backup Folder To Store The Backup
)

<#
.SYNOPSIS
	This PoSH Script Exports The FIM/MIM Configuration

.DESCRIPTION
	This PoSH script exports FIM/MIM configuration as a quick backup method. If applicabel, the following configuration components are exported:
		* FIM/MIM Main Configuration;
		* FIM/MIM Sync Configuration;
		* FIM/MIM Service Configuration;
		* FIM/MIM Portal Configuration;
		* FIM/MIM Registration Portal Configuration;
		* FIM/MIM Reset Portal Configuration;
		* SQL Server Database
		
	I have NOT added support for:
		* FIM/MIM PCNS Configuration
		* FIM/MIM CM Configuration
		* FIM/MIM Reporting Configuration

	Currently there is no import script. You will have to do it manually

.PARAMETER allConfig
	Exports All The Configuration Of FIM/MIM. This is basically all the options combined

.PARAMETER mainConfig
	Exports Only The Main Configuration Of FIM/MIM. This should be the option to use when upgrading FIM/MIM.

.PARAMETER fimSyncConfig
	Exports Only The FIM Sync Specific Configuration
	
.PARAMETER fimSvcConfig
	Exports Only The FIM Service Specific Configuration
	WARNING: This export might take some considerabel amount of time!!!
	
.PARAMETER fimPortalConfig
	Exports Only The FIM Portal Specific Configuration
	
.PARAMETER fimPwdRegPortalConfig
	Exports Only The FIM Password Registration Portal Specific Configuration
	
.PARAMETER fimPwdResetPortalConfig
	Exports Only The FIM Password Reset Portal Specific Configuration

.PARAMETER backupDBs
	Backup Only The Databases In Use By FIM

.PARAMETER mainBackupFolder
	Main Backup Folder To Store The Backup
	
.EXAMPLE
	Export All The FIM/MIM Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -allConfig -mainBackupFolder "D:\TEMP"

.EXAMPLE
	Export The Main FIM/MIM Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -mainConfig -mainBackupFolder "D:\TEMP"
	
.EXAMPLE
	Export The Main FIM/MIM Configuration And The FIM/MIM Sync Configuration And The FIM/MIM Service Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -mainConfig -fimSyncConfig -fimSvcConfig -mainBackupFolder "D:\TEMP"
	
.EXAMPLE
	Export The FIM/MIM Sync Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -fimSyncConfig -mainBackupFolder "D:\TEMP"

.EXAMPLE
	Export The FIM/MIM Service Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -fimSvcConfig -mainBackupFolder "D:\TEMP"	
	
.EXAMPLE
	Export The FIM/MIM Portal And The Password Registration And Reset Portal Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -fimPortalConfig -fimPwdRegPortalConfig -fimPwdResetPortalConfig -mainBackupFolder "D:\TEMP"

.EXAMPLE
	Export The FIM/MIM Portal And The Password Registration And Reset Portal Configuration To "D:\TEMP"
	
	.\Export-FIM-MIM-Configuration.ps1 -backupDBs -mainBackupFolder "D:\TEMP"

.NOTES
	This script administrator equivalent permissions on every targeted server
	
	If you specify an option to export, while that FIM/MIM component is not installed then nothing will happen
	
	Exporting the FIM/MIM Service might take some considerable amount of time as it enumerates the schema in the FIM/MIM service to export every object in it
#>

### FUNCTION: Load FIM/MIM PowerShell Snapins
Function loadFIMPosHCMDletsFromSnapins($snapInListToLoad) {
	foreach ($snapIn In $snapInListToLoad) {
		If(@(Get-PSSnapin | Where-Object {$_.Name -eq $snapIn} ).count -eq 0) {
			If(@(Get-PSSnapin -Registered | Where-Object {$_.Name -eq $snapIn} ).count -ne 0) {
				Add-PSSnapin $snapIn
				Write-Host "`nSnap-In '$snapIn' has been loaded...`n" -ForeGroundColor Green
			} Else {
				Write-Host "`nSnap-In '$snapIn' is not available to load...`n" -ForeGroundColor Red
			}
		} Else {
			Write-Host "`nSnap-In '$snapIn' already loaded...`n" -ForeGroundColor Yellow
		}
	}
}

### FUNCTION: Load FIM/MIM PowerShell Modules
Function loadFIMPosHCMDletsFromModules($modulesListToLoad) {
	ForEach($module In $modulesListToLoad) {
		If(@(Get-Module | Where-Object {$_.Name -eq $module}).count -eq 0) {
			If(@(Get-Module -ListAvailable | Where-Object {$_.Name -eq $module} ).count -ne 0) {
				Import-Module $module
				Write-Host "`nModule '$module' Has Been Loaded...`n" -ForeGroundColor Green
			} Else {
				Write-Host "`nModule '$module' Is Not Available To Load...`n" -ForeGroundColor Red
			}
		} Else {
			Write-Host "`nModule '$module' Already Loaded...`n" -ForeGroundColor Yellow
		}
	}
}

### FUNCTION: Convert a FIM ExportObject to a PowerShell PSObject
### http://www.identitytrench.com/2011/07/convert-fim-exportobject-to-powershell.html
Function convert-FimExportToPSObject() {
    Param ( 
        [parameter(Mandatory=$true, ValueFromPipeline = $true)] 
        [Microsoft.ResourceManagement.Automation.ObjectModel.ExportObject] 
        $exportObject 
    ) 
    Process {         
        $psObject = New-Object PSObject 
        $exportObject.ResourceManagementObject.ResourceManagementAttributes | %{ 
            if ($_.Value -ne $null) { 
                $value = $_.Value 
            } elseif($_.Values -ne $null) { 
                $value = $_.Values 
            } else { 
                $value = $null 
            } 
            $psObject | Add-Member -MemberType NoteProperty -Name $_.AttributeName -Value $value 
        } 
        Write-Output $psObject 
    } 
}

### FUNCTION: Export FIM/MIM Svc Configuration
Function exportFIMSvcConfig($fimSvcFQDN, $configToExport) {
	$sourceDataExportFile = $null
	$sourceDataExportPSObjectFile = $null
	$sourceData = $null
	$sourceDataSchema = $null
	$sourceDataSchemaObjectList = $null
	$customConfig = $null
	
	If ($configToExport -eq "schemaConfig") {
		$sourceDataExportFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-SchemaConfig.xml"
		$sourceDataExportPSObjectFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-SchemaConfig-PSObject.txt"
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -schemaConfig
	}
	If ($configToExport -eq "policyConfig") {
		$sourceDataExportFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-PolicyConfig.xml"
		$sourceDataExportPSObjectFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-PolicyConfig-PSObject.txt"
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -policyConfig
	}
	If ($configToExport -eq "portalConfig") {
		$sourceDataExportFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-PortalConfig.xml"
		$sourceDataExportPSObjectFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-PortalConfig-PSObject.txt"
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -portalConfig
	}
	If ($configToExport -eq "portalConfigUI") {
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -customConfig ("/PortalUIConfiguration")
	}
	If ($configToExport -eq "objectConfig" -Or "allConfig") {
		$sourceDataSchema = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -customConfig ("/ObjectTypeDescription")
		$sourceDataSchemaObjectList = $sourceDataSchema | convert-FimExportToPSObject | %{$_.Name}
		$customConfig = New-Object Collections.ArrayList
		$sourceDataSchemaObjectList | %{$customConfig.Add("/$_")} | Out-Null
	}
	If ($configToExport -eq "objectConfig") {
		$sourceDataExportFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-ObjectConfig.xml"
		$sourceDataExportPSObjectFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-ObjectConfig-PSObject.txt"
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -customConfig ($customConfig)
	}
	If ($configToExport -eq "allConfig") {
		$sourceDataExportFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-AllConfig.xml"
		$sourceDataExportPSObjectFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-AllConfig-PSObject.txt"
		$sourceData = Export-FIMConfig -uri $("http://"+$fimSvcFQDN+":5725/ResourceManagementService") -schemaConfig -policyConfig -portalConfig -customConfig ($customConfig)
	}
	
	If ($sourceData) {
		If ($sourceDataExportFile -And $sourceDataExportPSObjectFile) {
			Write-Host "Export Type.....................: $configToExport" -ForeGroundColor Green
			Write-Host "Number Of Objects Exported......: $($sourceData.count)`n" -ForeGroundColor Green
				
			$sourceData | ConvertFrom-FIMResource -file $sourceDataExportFile
			
			$sourceData | convert-FimExportToPSObject | Out-File $sourceDataExportPSObjectFile
		} Else {
			$fimPortalPortalUIConfiguration = $sourceData | convert-FimExportToPSObject | ?{$_.ObjectType -eq "PortalUIConfiguration"}
			Return $fimPortalPortalUIConfiguration
		}
	} Else {
		Write-Host "`nNo Data Was Exported From FIM/MIM!...`n" -ForeGroundColor Red
	}
}

### Clear The Screen
Clear-Host

### Configure The Appropriate Screen And Buffer Size To Make Sure Everything Fits Nicely
$uiConfig = (Get-Host).UI.RawUI
$uiConfig.WindowTitle = "+++ EXPORT FIM/MIM Configuration +++"
$uiConfig.ForegroundColor = "Yellow"
$uiConfigBufferSize = $uiConfig.BufferSize
$uiConfigBufferSize.Width = 140
$uiConfigBufferSize.Height = 9999
$uiConfigScreenSizeMax = $uiConfig.MaxPhysicalWindowSize
$uiConfigScreenSizeMaxWidth = $uiConfigScreenSizeMax.Width
$uiConfigScreenSizeMaxHeight = $uiConfigScreenSizeMax.Height
$uiConfigScreenSize = $uiConfig.WindowSize
If ($uiConfigScreenSizeMaxWidth -lt 140) {
	$uiConfigScreenSize.Width = $uiConfigScreenSizeMaxWidth
} Else {
	$uiConfigScreenSize.Width = 140
}
If ($uiConfigScreenSizeMaxHeight -lt 75) {
	$uiConfigScreenSize.Height = $uiConfigScreenSizeMaxHeight - 5
} Else {
	$uiConfigScreenSize.Height = 75
}
$uiConfig.BufferSize = $uiConfigBufferSize
$uiConfig.WindowSize = $uiConfigScreenSize

Write-Host ""
Write-Host "**********************************************************" -ForeGroundColor Cyan
Write-Host "*                                                        *" -ForeGroundColor Cyan
Write-Host "*       --> Export The FIM/MIM Configuration <--         *" -ForeGroundColor Cyan
Write-Host "*                                                        *" -ForeGroundColor Cyan
Write-Host "*      Written By: Jorge de Almeida Pinto [MVP-EMS]      *" -ForeGroundColor Cyan
Write-Host "*                                                        *" -ForeGroundColor Cyan
Write-Host "**********************************************************" -ForeGroundColor Cyan
Write-Host ""

If (!$allConfig -And !$mainConfig -And !$fimSyncConfig -And !$fimSvcConfig -And !$fimPortalConfig -And !$fimPwdRegPortalConfig -And !$fimPwdResetPortalConfig -And !$backupDBs) {
	Write-Host ""
	Write-Host "No Option Was Specified To Export Something!" -ForeGroundColor Red
	Write-Host "Aborting Script!" -ForeGroundColor Red
	Write-Host ""
	EXIT
}

If (!$mainBackupFolder) {
	Write-Host ""
	Write-Host "No Export Folder Was Specified!" -ForeGroundColor Red
	Write-Host "Aborting Script!" -ForeGroundColor Red
	Write-Host ""
	EXIT
}

Write-Host ""
Write-Host "WARNING: For Obvious Reasons This Script DOES NOT Export Configurations Such As:..." -ForeGroundColor Red
Write-Host "   * Local/Remote Scripts/Tools" -ForegroundColor Red
Write-Host "   * Scheduled Tasks" -ForegroundColor Red
Write-Host "   * User Rights" -ForegroundColor Red
Write-Host "   * Permissions On Either The File Or The Registry" -ForegroundColor Red
Write-Host "   * Custom Databases"  -ForegroundColor Red
Write-Host "   * Anything Related To PCNS" -ForegroundColor Red
Write-Host "   * Anything Related To FIM CM" -ForegroundColor Red
Write-Host "   * Anything Related To FIM Reporting" -ForegroundColor Red
Write-Host ""
Write-Host "If you Want To This Script To Take Care Of That Too, Then Adjust The Script As Needed" -ForegroundColor Red
Write-Host ""

Write-Host "Press Any Key To Continue..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

### Definition Of Some Constants
$currentScriptFolderPath = Split-Path $MyInvocation.MyCommand.Definition
$execDateTime = Get-Date
$execDateTimeYEAR = $execDateTime.Year
$execDateTimeMONTH = $execDateTime.Month
$execDateTimeDAY = $execDateTime.Day
$execDateTimeHOUR = $execDateTime.Hour
$execDateTimeMINUTE = $execDateTime.Minute
$execDateTimeSECOND = $execDateTime.Second
$execDateTimeCustom = [STRING]$execDateTimeYEAR + "-" + $("{0:D2}" -f $execDateTimeMONTH) + "-" + $("{0:D2}" -f $execDateTimeDAY) + "_" + $("{0:D2}" -f $execDateTimeHOUR) + "." + $("{0:D2}" -f $execDateTimeMINUTE) + "." + $("{0:D2}" -f $execDateTimeSECOND)
$localComputerFQDN = $(Get-WmiObject -Class Win32_ComputerSystem).Name + "." + $(Get-WmiObject -Class Win32_ComputerSystem).Domain
$backupFolderFullPath = Join-Path $mainBackupFolder $($execDateTimeCustom + "_FIM-MIM-Config_" + $localComputerFQDN)
If (!(Test-Path $backupFolderFullPath)) {
	New-item $backupFolderFullPath -ItemType Directory | Out-Null
}

Write-Host ""
Write-Host "Folder Containing Exports/Backup.............: $backupFolderFullPath"
Write-Host ""

$fimSyncLocation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Synchronization Service" -ErrorAction SilentlyContinue).Location
$fimSvcLocation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Service" -ErrorAction SilentlyContinue).Location
$fimFortalLocation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Portal" -ErrorAction SilentlyContinue).Location
$fimPwdRegPortalLocation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Password Registration Portal" -ErrorAction SilentlyContinue).Location
$fimPwdResetPortalLocation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Password Reset Portal" -ErrorAction SilentlyContinue).Location
$sqlServerInstances = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server" -ErrorAction SilentlyContinue).InstalledInstances

# General FIM/MIM Configuration
If ($fimSyncLocation -Or $fimSvcLocation -Or $fimFortalLocation -Or $fimPwdRegPortalLocation -Or $fimPwdResetPortalLocation) {
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Exporting Data From The Registry..."
		$generalFIMConfigFile = Join-Path $backupFolderFullPath "General-FIM-MIM-Config.reg"
		REG EXPORT "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Forefront Identity Manager" $generalFIMConfigFile | Out-Null
	}
}

# FIM/MIM Sync Configuration Export
If ($fimSyncLocation) {
	If ($mainConfig -Or $fimSyncConfig -Or $allConfig) {
		If ($fimSyncLocation -notmatch "Synchronization") {
			$fimSyncLocation = Join-Path $fimSyncLocation "Synchronization Service"
		}
		$fimSyncBackupFolder = Join-Path $backupFolderFullPath "FIM-MIM-Sync"
		If (!(Test-Path $fimSyncBackupFolder)) {
			New-item $fimSyncBackupFolder -ItemType Directory | Out-Null
		}
	}
	
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM SYNC MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $fimSyncLocation -Destination $fimSyncBackupFolder -Recurse -Filter *.config -Force

		Write-Host ""
		Write-Host "Exporting Data From The Registry..."		
		$fimSyncSvcConfigFile = Join-Path $fimSyncBackupFolder "FIM-MIM-Sync-Svc-Config.reg"
		REG EXPORT "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\FIMSynchronizationService" $fimSyncSvcConfigFile | Out-Null

		Write-Host ""
		Write-Host "Copying Files..."		
		Copy-Item -Path $(Join-Path $fimSyncLocation "SourceCode") -Destination $(Join-Path $fimSyncBackupFolder "Synchronization Service\SourceCode") -Recurse -Force
	}
	
	If ($fimSyncConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM SYNC SPECIFIC CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $(Join-Path $fimSyncLocation "Extensions") -Destination $(Join-Path $fimSyncBackupFolder "Synchronization Service\Extensions") -Recurse -Force
		Copy-Item -Path $(Join-Path $fimSyncLocation "MaData") -Destination $(Join-Path $fimSyncBackupFolder "Synchronization Service\MaData") -Recurse -Force

		$fimSyncConnectorsBackupFolder = Join-Path $fimSyncBackupFolder "Connectors"
		If (!(Test-Path $fimSyncConnectorsBackupFolder)) {
			New-item $fimSyncConnectorsBackupFolder -ItemType Directory | Out-Null
		}
		
		Write-Host ""
		Write-Host "Exporting Management Agents/Connectors..."
		$listOfConfiguredConnectors = Get-WMIObject -class "MIIS_ManagementAgent" -namespace "root\MicrosoftIdentityIntegrationServer" | %{$_.Name}
		$listOfConfiguredConnectors | %{
			$fimSyncConnectorName = $_
			&"$fimSyncLocation\Bin\maexport.exe" $fimSyncConnectorName $(Join-Path $fimSyncConnectorsBackupFolder $($fimSyncConnectorName + ".xml")) | Out-Null
		}
		
		$fimSyncSrvExportBackupFolder = Join-Path $fimSyncBackupFolder "Srv-Export"
		If (!(Test-Path $fimSyncSrvExportBackupFolder)) {
			New-item $fimSyncSrvExportBackupFolder -ItemType Directory | Out-Null
		}
		Write-Host ""
		Write-Host "Exporting Server Configuration..."
		&"$fimSyncLocation\Bin\svrexport.exe" $fimSyncSrvExportBackupFolder /v | Out-Null
		
		$fimSyncSvcEncryptionKeyFile = Join-Path $fimSyncBackupFolder "Encryption-Key.bin"
		$fimSyncSvcAccount = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\FIMSynchronizationService").ObjectName
		$fimSyncSvcAccountPassword = Read-Host "What Is The Password Of The FIM/MIM Sync Service Account?"
		Write-Host ""
		Write-Host "Exporting Encryption Key..."
		&"$fimSyncLocation\Bin\miiskmu.exe" /e $fimSyncSvcEncryptionKeyFile /u:$fimSyncSvcAccount $fimSyncSvcAccountPassword  | Out-Null
	}
}

# FIM/MIM Svc Configuration
If ($fimSvcLocation) {
	If ($mainConfig -Or $fimSvcConfig -Or $allConfig) {
		$fimSvcBackupFolder = Join-Path $backupFolderFullPath "FIM-MIM-Svc"
		If (!(Test-Path $fimSvcBackupFolder)) {
			New-item $fimSvcBackupFolder -ItemType Directory | Out-Null
		}
	}
	
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM SERVICE MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.config -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.dll -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.xml -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.txt -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.pfx -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.p12 -Force
		Copy-Item -Path $fimSvcLocation -Destination $fimSvcBackupFolder -Recurse -Filter *.sql -Force

		Write-Host ""
		Write-Host "Exporting Data From The Registry..."	
		$fimSvcConfigFile = Join-Path $fimSvcBackupFolder "FIM-MIM-Svc-Config.reg"
		REG EXPORT "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\FIMService" $fimSvcConfigFile | Out-Null
	}
	If ($fimSvcConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM SERVICE SPECIFIC CONFIGURATION +++" -ForeGroundColor Cyan
		loadFIMPosHCMDletsFromSnapins FIMAutomation
		
		$fimSvcResourceManagementConfigFile = Join-Path $fimSvcLocation "Microsoft.ResourceManagement.Service.exe.config"
		[XML]$fimSvcResourceManagementConfig = Get-Content $fimSvcResourceManagementConfigFile
		$fimSvcFQDN = $fimSvcResourceManagementConfig.configuration.resourceManagementClient.resourceManagementServiceBaseAddress

		Write-Host ""
		Write-Host "Exporting Schema Configuration From The FIM/MIM Service..."
		exportFIMSvcConfig $fimSvcFQDN schemaConfig
		
		Write-Host ""
		Write-Host "Exporting Policy Configuration From The FIM/MIM Service..."
		exportFIMSvcConfig $fimSvcFQDN policyConfig

		Write-Host ""
		Write-Host "Exporting Portal Configuration From The FIM/MIM Service..."
		exportFIMSvcConfig $fimSvcFQDN portalConfig
		
		Write-Host ""
		Write-Host "Exporting All Objects From The FIM/MIM Service..."
		exportFIMSvcConfig $fimSvcFQDN objectConfig

		Write-Host ""
		Write-Host "Exporting Everything (Schema, Policy, Portal, Objects) From The FIM/MIM Service..."
		exportFIMSvcConfig $fimSvcFQDN allConfig
	}
}

# FIM/MIM Portal Configuration
If ($fimFortalLocation) {
	If ($mainConfig -Or $fimPortalConfig -Or $allConfig) {
		$fimPortalBackupFolder = Join-Path $backupFolderFullPath "FIM-MIM-Portal"
		If (!(Test-Path $fimPortalBackupFolder)) {
			New-item $fimPortalBackupFolder -ItemType Directory | Out-Null
		}
	}
	
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PORTAL MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		loadFIMPosHCMDletsFromSnapins Microsoft.Sharepoint.PowerShell
		loadFIMPosHCMDletsFromModules WebAdministration
		$fimPortalSiteCollectionURL = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Portal").BaseSiteCollectionURL
		$fimPortalWebsiteName = (Get-SPWebApplication -Identity $fimPortalSiteCollectionURL).DisplayName
		$fimPortalWebsitePath = (Get-Website | ?{$_.Name -eq $fimPortalWebsiteName}).PhysicalPath
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $(Join-Path $fimPortalWebsitePath "web.config") -Destination $(Join-Path $fimPortalBackupFolder $($fimPortalWebsiteName + "_web.config")) -Force
		
		$webConfigFile = (Get-WebConfigFile).FullName
		Copy-Item -Path $webConfigFile -Destination $fimPortalBackupFolder -Force
	}
	If ($fimPortalConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PORTAL SPECIFIC CONFIGURATION +++" -ForeGroundColor Cyan
		loadFIMPosHCMDletsFromSnapins Microsoft.Sharepoint.PowerShell,FIMAutomation
		
		$fimPortalLogosBackupFolder = Join-Path $fimPortalBackupFolder "Logos"
		If (!(Test-Path $fimPortalLogosBackupFolder)) {
			New-item $fimPortalLogosBackupFolder -ItemType Directory | Out-Null
		}
		
		$fimSvcFQDN = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Portal").ServiceAddress
		$fimPortalSiteCollectionURL = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Forefront Identity Manager\2010\Portal").BaseSiteCollectionURL
		$fimPortalPortalUIConfiguration = exportFIMSvcConfig $fimSvcFQDN portalConfigUI
		$fimPortalBrandingImageLeft = $fimPortalPortalUIConfiguration.BrandingLeftImage
		$fimPortalBrandingImageLeft = $fimPortalBrandingImageLeft.Substring($fimPortalBrandingImageLeft.LastIndexOf("/") + 1)
		$fimPortalBrandingImageRight = $fimPortalPortalUIConfiguration.BrandingRightImage
		$fimPortalBrandingImageRight = $fimPortalBrandingImageRight.Substring($fimPortalBrandingImageRight.LastIndexOf("/") + 1)
		$fimPortalCompatLevel = (Get-SPSite -Identity $fimPortalSiteCollectionURL).CompatibilityLevel
		$fimPortalImagesFolder = "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\$fimPortalCompatLevel\TEMPLATE\IMAGES\MSILM2"
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $(Join-Path $fimPortalImagesFolder $fimPortalBrandingImageLeft) -Destination $fimPortalLogosBackupFolder -Force
		Copy-Item -Path $(Join-Path $fimPortalImagesFolder $fimPortalBrandingImageRight) -Destination $fimPortalLogosBackupFolder -Force
	}
}

# FIM/MIM Password Registration Portal Configuration
If ($fimPwdRegPortalLocation) {
	If ($mainConfig -Or $fimPwdRegPortalConfig -Or $allConfig) {
		$fimPwdRegPortalBackupFolder = Join-Path $backupFolderFullPath "FIM-MIM-PwdRegPortal"
		If (!(Test-Path $fimPwdRegPortalBackupFolder)) {
			New-item $fimPwdRegPortalBackupFolder -ItemType Directory | Out-Null
		}
	}
	
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PASSWORD REGISTRATION PORTAL MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $(Join-Path $fimPwdRegPortalLocation "*.config") -Destination $fimPwdRegPortalBackupFolder -Force
	}
	If ($fimPwdRegPortalConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PASSWORD REGISTRATION PORTAL SPECIFIC CONFIGURATION +++" -ForeGroundColor Cyan
		If (Test-Path $(Join-Path $fimPwdRegPortalLocation "Customizations")) {
			Write-Host ""
			Write-Host "Copying Files..."
			Copy-Item -Path $(Join-Path $fimPwdRegPortalLocation "Customizations") -Destination $(Join-Path $fimPwdRegPortalBackupFolder "Customizations") -Recurse -Force
		}
	}
}

# FIM/MIM Password Reset Portal Configuration
If ($fimPwdResetPortalLocation) {
	If ($mainConfig -Or $fimPwdResetPortalConfig -Or $allConfig) {
		$fimPwdResetPortalBackupFolder = Join-Path $backupFolderFullPath "FIM-MIM-PwdResetPortal"
		If (!(Test-Path $fimPwdResetPortalBackupFolder)) {
			New-item $fimPwdResetPortalBackupFolder -ItemType Directory | Out-Null
		}
	}
	
	If ($mainConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PASSWORD RESET PORTAL MAIN CONFIGURATION +++" -ForeGroundColor Cyan
		Write-Host ""
		Write-Host "Copying Files..."
		Copy-Item -Path $(Join-Path $fimPwdResetPortalLocation "*.config") -Destination $fimPwdResetPortalBackupFolder -Force
	}
	If ($fimPwdResetPortalConfig -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ EXPORTING/BACKING UP FIM/MIM PASSWORD RESET PORTAL SPECIFIC CONFIGURATION +++" -ForeGroundColor Cyan
		If (Test-Path $(Join-Path $fimPwdResetPortalLocation "Customizations")) {
			Write-Host ""
			Write-Host "Copying Files..."
			Copy-Item -Path $(Join-Path $fimPwdResetPortalLocation "Customizations") -Destination $(Join-Path  $fimPwdResetPortalBackupFolder "Customizations") -Recurse -Force
		}
	}
}

# FIM/MIM SQL Backups
If ($sqlServerInstances) {
#If ($fimSyncLocation -Or $fimSvcLocation -Or $sqlServerInstances) {
	If ($backupDBs -Or $allConfig) {
		Write-Host ""
		Write-Host "------------------------------------------------------------------------------------------------------------------------------------" -ForeGroundColor DarkCyan
		Write-Host "+++ BACKING UP FIM/MIM DATABASES +++" -ForeGroundColor Cyan
		$sqlServerBackupFolder = Join-Path $backupFolderFullPath "SQL-Server-DBs"
		If (!(Test-Path $sqlServerBackupFolder)) {
			New-item $sqlServerBackupFolder -ItemType Directory | Out-Null
		}

		# Load Assemblies
		[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
		[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null
		[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null
		[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum") | Out-Null
		
		#If ($fimSyncLocation) {
		#	$fimSyncSvcSQLServerFQDN = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\FIMSynchronizationService\Parameters" -ErrorAction SilentlyContinue).Server
		#	$fimSyncSvcDB = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\FIMSynchronizationService\Parameters" -ErrorAction SilentlyContinue).DBName
		#	$fimSyncSvcSQLServer = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $fimSyncSvcSQLServerFQDN
		#	$databasesOnFimSyncSvcSQLServer = $fimSyncSvcSQLServer.Databases
		#	$databasesOnFimSyncSvcSQLServer | ?{$_.Name -eq $fimSyncSvcDB} | %{
		#		$dbName = $_.Name
		#		$smoBackup = New-Object ("Microsoft.SqlServer.Management.Smo.Backup")
		#		Write-Host ""
		#		Write-Host "Creating Backup Of '$dbName'" -ForegroundColor Yellow
		#		$smoBackup.Action = "Database"
		#		$smoBackup.BackupSetDescription = "Full Backup Of " + $dbName
		#		$smoBackup.BackupSetName = $dbName + " Backup"
		#		$smoBackup.Database = $dbName
		#		$smoBackup.MediaDescription = "Disk"
		#		$smoBackup.Devices.AddDevice($sqlServerBackupFolder + "\SQL_BCK_" + $dbName + ".bak", "File")
		#		$smoBackup.SqlBackup($fimSyncSvcSQLServer)
		#	}
		#	
		#	$fimSyncSvcDBSQLJobs = Join-Path $sqlServerBackupFolder "FIM-MIM-Sync-Svc-SQL-Jobs.xml"
		#	$fimSyncSvcSQLServer.JobServer.Jobs | Export-Clixml $fimSyncSvcDBSQLJobs
		#}
		#If ($fimSvcLocation) {
		#	$fimSvcSQLServerFQDN = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\FIMService" -ErrorAction SilentlyContinue).DatabaseServer
		#	$fimSvcDB = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\FIMService" -ErrorAction SilentlyContinue).DatabaseName
		#	$fimSvcSQLServer = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $fimSvcSQLServerFQDN
		#	$databasesOnFimSvcSQLServer = $fimSvcSQLServer.Databases
		#	$databasesOnFimSvcSQLServer | ?{$_.Name -eq $fimSvcDB} | %{
		#		$dbName = $_.Name
		#		$smoBackup = New-Object ("Microsoft.SqlServer.Management.Smo.Backup")
		#		Write-Host ""
		#		Write-Host "Creating Backup Of '$dbName'" -ForegroundColor Yellow
		#		$smoBackup.Action = "Database"
		#		$smoBackup.BackupSetDescription = "Full Backup Of " + $dbName
		#		$smoBackup.BackupSetName = $dbName + " Backup"
		#		$smoBackup.Database = $dbName
		#		$smoBackup.MediaDescription = "Disk"
		#		$smoBackup.Devices.AddDevice($sqlServerBackupFolder + "\SQL_BCK_" + $dbName + ".bak", "File")
		#		$smoBackup.SqlBackup($fimSvcSQLServer)
		#	}
		#				
		#	$fimSvcDBSQLJobs = Join-Path $sqlServerBackupFolder "FIM-MIM-Svc-SQL-Jobs.xml"
		#	$fimSvcSQLServer.JobServer.Jobs | Export-Clixml $fimSvcDBSQLJobs
		#}
		If ($sqlServerInstances) {
			$fimSQLServerFQDN = $localComputerFQDN
			$fimSyncSvcDB = "FIMSynchronizationService"
			$fimSvcDB = "FIMService"
			$fimSQLServer = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $fimSQLServerFQDN
			$databasesOnFimSQLServer = $fimSQLServer.Databases
			$databasesOnFimSQLServer | ?{$_.Name -eq $fimSyncSvcDB -Or $_.Name -eq $fimSvcDB} | %{
				$dbName = $_.Name
				If (!(Test-Path $(Join-Path $sqlServerBackupFolder $("\SQL_BCK_" + $dbName + ".bak")))) {
					$smoBackup = New-Object ("Microsoft.SqlServer.Management.Smo.Backup")
					Write-Host ""
					Write-Host "Backing Up '$dbName'..."
					$smoBackup.Action = "Database"
					$smoBackup.BackupSetDescription = "Full Backup Of " + $dbName
					$smoBackup.BackupSetName = $dbName + " Backup"
					$smoBackup.Database = $dbName
					$smoBackup.MediaDescription = "Disk"
					$smoBackup.Devices.AddDevice($sqlServerBackupFolder + "\SQL_BCK_" + $dbName + ".bak", "File")
					$smoBackup.SqlBackup($fimSQLServer)
				}
			}
			
			Write-Host ""
			Write-Host "Exporting SQL Server Jobs..."
			$fimDBSQLJobs = Join-Path $sqlServerBackupFolder "FIM-MIM-SQL-Jobs.xml"
			$fimSQLServer.JobServer.Jobs | Export-Clixml $fimDBSQLJobs
		}
	}
}

Write-Host ""
Write-Host "DONE!"
Write-Host ""